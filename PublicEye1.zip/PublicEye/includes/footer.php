<footer>
  <div class="footer-container">
    

    <div class="footer-brand">
      <h2>Public Eye</h2>
    </div>


    <div class="footer-social">
      <a href="#" target="_blank">
        <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/facebook.svg" alt="Facebook">
      </a>
      <a href="#" target="_blank">
        <img src="https://cdn.jsdelivr.net/gh/simple-icons/simple-icons/icons/instagram.svg" alt="Instagram">
      </a>
    </div>

    <div class="footer-contact">
      <p>📞 9767410477</p>
      <p>📧 pujanshakya124@gmail.com</p>
    </div>
  </div>

  <div class="footer-bottom">
    <p>© <?php echo date("Y"); ?> Public Eye. All Rights Reserved.</p>
  </div>
</footer>
